

train_set='/Users/hakuri/Desktop/test/train_date_set1.txt'
test_root='/Users/hakuri/Desktop/'
number_jieba=10
number_day=32
hot_rate=30